package com.screenrefresh.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int PICK_IMAGE = 41;
    // Page and image are served from this local https address (no file:// restrictions)
    private static final String HOST = "appassets.androidplatform.net";
    private static final String BASE = "https://" + HOST + "/";
    private static final String IMAGE_NAME = "shot.img";

    private WebView web;
    private volatile boolean fullscreen = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath() == null ? "/" : u.getPath();
                try {
                    if (path.equals("/") || path.equals("/index.html")) {
                        return ok("text/html", getAssets().open("index.html"));
                    }
                    if (path.equals("/shot")) {
                        File f = imageFile();
                        if (!f.exists()) return null;
                        return ok(mimeOf(f), new FileInputStream(f));
                    }
                } catch (Exception e) {
                    return null;
                }
                return null;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        setContentView(web);
        applyFullscreen();
        web.loadUrl(BASE + "index.html");
    }

    private static WebResourceResponse ok(String mime, InputStream in) {
        WebResourceResponse r = new WebResourceResponse(mime, mime.startsWith("text") ? "utf-8" : null, in);
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        h.put("Access-Control-Allow-Origin", "*");
        r.setResponseHeaders(h);
        return r;
    }

    private static String mimeOf(File f) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        return o.outMimeType != null ? o.outMimeType : "image/jpeg";
    }

    private File imageFile() {
        return new File(getFilesDir(), IMAGE_NAME);
    }

    private String imageUrl() {
        File f = imageFile();
        return f.exists() && f.length() > 0 ? BASE + "shot?v=" + f.lastModified() : "";
    }

    /* ---------- Full screen (hide status bar + nav buttons) ---------- */

    private void applyFullscreen() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(!fullscreen);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                if (fullscreen) {
                    c.hide(WindowInsets.Type.systemBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } else {
                    c.show(WindowInsets.Type.systemBars());
                }
            }
        } else {
            int flags = 0;
            if (fullscreen) {
                flags = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            }
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyFullscreen();
    }

    /* ---------- Image picking + storage (original file, no compression) ---------- */

    private void openPicker() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 33) {
            i = new Intent(MediaStore.ACTION_PICK_IMAGES);
        } else {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
        }
        try {
            startActivityForResult(i, PICK_IMAGE);
        } catch (Exception e) {
            Intent f = new Intent(Intent.ACTION_GET_CONTENT);
            f.addCategory(Intent.CATEGORY_OPENABLE);
            f.setType("image/*");
            startActivityForResult(f, PICK_IMAGE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
            uri = data.getClipData().getItemAt(0).getUri();
        }
        if (uri == null) { jsError(); return; }

        File tmp = new File(getFilesDir(), IMAGE_NAME + ".tmp");
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(tmp)) {
            if (in == null) { jsError(); return; }
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } catch (Exception e) {
            jsError();
            return;
        }
        File dest = imageFile();
        dest.delete();
        if (!tmp.renameTo(dest)) { jsError(); return; }
        dest.setLastModified(System.currentTimeMillis());
        web.evaluateJavascript("window.onNativeImage && window.onNativeImage('" + imageUrl() + "')", null);
    }

    private void jsError() {
        web.evaluateJavascript("window.onNativeError && window.onNativeError()", null);
    }

    /* ---------- Back button closes settings first ---------- */

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.handleBack ? window.handleBack() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    /* ---------- JS bridge ---------- */

    private class Bridge {
        @JavascriptInterface
        public void pickImage() {
            runOnUiThread(MainActivity.this::openPicker);
        }

        @JavascriptInterface
        public String getImage() {
            return imageUrl();
        }

        @JavascriptInterface
        public void clearImage() {
            imageFile().delete();
        }

        @JavascriptInterface
        public int getVersionCode() {
            try {
                return (int) getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            } catch (Exception e) {
                return 0;
            }
        }

        @JavascriptInterface
        public String getVersionName() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void openUrl(String url) {
            if (url == null || !url.startsWith("https://github.com/uniquehubmail-bit/screen-refresh-app/")) return;
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void setFullscreen(boolean on) {
            fullscreen = on;
            runOnUiThread(MainActivity.this::applyFullscreen);
        }
    }
}
