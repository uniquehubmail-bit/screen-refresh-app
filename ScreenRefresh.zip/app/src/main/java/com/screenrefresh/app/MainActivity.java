package com.screenrefresh.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int PICK_IMAGE = 41;
    private static final String PREFIX = "shot_";

    private WebView web;
    private volatile boolean fullscreen = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true); // lets the page read the image's top color
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        setContentView(web);
        applyFullscreen();
        web.loadUrl("file:///android_asset/index.html");
    }

    /* ---------- Full screen (hide status bar + nav buttons) ---------- */

    private void applyFullscreen() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(!fullscreen);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                if (fullscreen) {
                    c.hide(WindowInsets.Type.systemBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } else {
                    c.show(WindowInsets.Type.systemBars());
                }
            }
        } else {
            int flags = 0;
            if (fullscreen) {
                flags = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            }
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyFullscreen();
    }

    /* ---------- Image picking + storage (original file, no compression) ---------- */

    private void openPicker() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 33) {
            i = new Intent(MediaStore.ACTION_PICK_IMAGES);
        } else {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
        }
        try {
            startActivityForResult(i, PICK_IMAGE);
        } catch (Exception e) {
            Intent f = new Intent(Intent.ACTION_GET_CONTENT);
            f.addCategory(Intent.CATEGORY_OPENABLE);
            f.setType("image/*");
            startActivityForResult(f, PICK_IMAGE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        File out = new File(getFilesDir(), PREFIX + System.currentTimeMillis());
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            if (in == null) return;
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } catch (Exception e) {
            return;
        }
        deleteOldImages(out);
        String url = Uri.fromFile(out).toString();
        web.evaluateJavascript("window.onNativeImage && window.onNativeImage('" + url + "')", null);
    }

    private File currentImage() {
        File[] files = getFilesDir().listFiles();
        File best = null;
        if (files != null) {
            for (File f : files) {
                if (f.getName().startsWith(PREFIX) && (best == null || f.lastModified() > best.lastModified())) best = f;
            }
        }
        return best;
    }

    private void deleteOldImages(File keep) {
        File[] files = getFilesDir().listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.getName().startsWith(PREFIX) && (keep == null || !f.equals(keep))) f.delete();
        }
    }

    /* ---------- Back button closes settings first ---------- */

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.handleBack ? window.handleBack() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    /* ---------- JS bridge ---------- */

    private class Bridge {
        @JavascriptInterface
        public void pickImage() {
            runOnUiThread(MainActivity.this::openPicker);
        }

        @JavascriptInterface
        public String getImage() {
            File f = currentImage();
            return f == null ? "" : Uri.fromFile(f).toString();
        }

        @JavascriptInterface
        public void clearImage() {
            deleteOldImages(null);
        }

        @JavascriptInterface
        public void setFullscreen(boolean on) {
            fullscreen = on;
            runOnUiThread(MainActivity.this::applyFullscreen);
        }
    }
}
