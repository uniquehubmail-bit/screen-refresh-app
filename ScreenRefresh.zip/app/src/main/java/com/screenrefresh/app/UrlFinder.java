package com.screenrefresh.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.media.ExifInterface;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.File;
import java.util.regex.Pattern;

/**
 * Reads the text in the top part of a screenshot on the phone (no internet needed)
 * and finds the web address shown in the browser bar.
 * Result coordinates are in the image's own pixels (after EXIF rotation),
 * the same space the page uses to draw the image.
 */
final class UrlFinder {

    interface Callback { void done(String jsonOrNull); }

    // something.tld or something.tld/path — what a browser bar shows
    private static final Pattern URLISH = Pattern.compile(
            "^(https?://)?(www\\.)?[a-z0-9][a-z0-9-]*(\\.[a-z0-9-]+)*\\.[a-z]{2,}(/\\S*)?$",
            Pattern.CASE_INSENSITIVE);

    private static TextRecognizer recognizer;

    static void find(File file, Callback cb) {
        new Thread(() -> {
            try {
                // Decode (downsampled if huge) and apply EXIF rotation like the WebView does
                BitmapFactory.Options b = new BitmapFactory.Options();
                b.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(file.getAbsolutePath(), b);
                int sample = 1;
                while (Math.max(b.outWidth, b.outHeight) / sample > 2600) sample *= 2;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = sample;
                Bitmap bm = BitmapFactory.decodeFile(file.getAbsolutePath(), o);
                if (bm == null) { cb.done(null); return; }
                int rot = 0;
                try {
                    int or = new ExifInterface(file.getAbsolutePath())
                            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    if (or == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
                } catch (Exception ignored) { }
                if (rot != 0) {
                    Matrix m = new Matrix();
                    m.postRotate(rot);
                    bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
                }
                final int fullW = bm.getWidth(), fullH = bm.getHeight();
                final int scanH = Math.max(1, (int) (fullH * 0.40)); // browser bar lives near the top
                Bitmap top = Bitmap.createBitmap(bm, 0, 0, fullW, scanH);
                final int scale = sample;

                synchronized (UrlFinder.class) {
                    if (recognizer == null) recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                }
                recognizer.process(InputImage.fromBitmap(top, 0))
                        .addOnSuccessListener(text -> cb.done(pick(text, fullW, fullH, scale)))
                        .addOnFailureListener(e -> cb.done(null));
            } catch (Throwable t) {
                cb.done(null);
            }
        }).start();
    }

    private static String pick(Text text, int w, int h, int scale) {
        Text.Element best = null;
        String bestText = null;
        int bestScore = Integer.MIN_VALUE;
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element el : line.getElements()) {
                    Rect r = el.getBoundingBox();
                    if (r == null) continue;
                    String t = el.getText().trim().replaceAll("[\\s|]+", "");
                    if (t.length() < 4 || !URLISH.matcher(t).matches()) continue;
                    // Prefer: has a path or www, longer, nearer the top
                    int score = t.length() * 3 - r.top / 8;
                    if (t.contains("/")) score += 40;
                    if (t.toLowerCase().startsWith("www.") || t.toLowerCase().startsWith("http")) score += 25;
                    if (t.matches("^\\d+(\\.\\d+)+.*")) score -= 200; // times, versions, IPs
                    if (score > bestScore) { bestScore = score; best = el; bestText = t; }
                }
            }
        }
        if (best == null) return null;
        Rect r = best.getBoundingBox();
        try {
            JSONObject j = new JSONObject();
            j.put("text", bestText);
            j.put("x", r.left * scale);
            j.put("y", r.top * scale);
            j.put("w", r.width() * scale);
            j.put("h", r.height() * scale);
            j.put("iw", w * scale);
            j.put("ih", h * scale);
            return j.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private UrlFinder() { }
}
